// Get the json file online
//jQuery.getJSON('https://www.unisport.dk/api/sample/', function (data) {
// Get the json file locally	
jQuery.getJSON('download.json', function (data) {
// Log the json file in the console
//console.log(data);
	$.each(data.products, function() {
	$('#products').append(
	'<div class="col-xs-7 col-md-3"><div id="outer_div" class=""><a target="_blank" href="' + this.url + '"><img class="col-md-12" src="' + this.image + '" /img><img id="shadow" class="col-md-12" src="https://unisport-assets.s3.amazonaws.com/styleguide/img/shadow.png" /img></a><h1>' + this.name + '</h1><p>Vejl. pris:<span id="bigger"> ' + this.price + '</span>' + ' ' + '<span id="smaller">' + this.currency + '</span>' +'</p><p>Levering: ' + this.delivery +'</p><p id="sizes">STØRRELSE: '+ this.sizes +'</p></div></div>'
	);		
	});
});	 